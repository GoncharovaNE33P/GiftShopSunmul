package com.example.giftshopsunmul.model

data class categories(
    val id: String,
    val title: String
)
