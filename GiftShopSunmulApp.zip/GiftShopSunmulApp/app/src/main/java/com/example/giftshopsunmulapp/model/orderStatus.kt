package com.example.giftshopsunmulapp.model

data class orderStatus(
    val id: String,
    val title: String
)
