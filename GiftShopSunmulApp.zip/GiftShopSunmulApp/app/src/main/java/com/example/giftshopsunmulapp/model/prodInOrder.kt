package com.example.giftshopsunmulapp.model

data class prodInOrder(
    val id: String,
    val products_id: String,
    val orders_id: String,
    val count: Int
)
