package com.example.giftshopsunmulapp.model

data class countryProd(
    val id: String,
    val title: String
)
