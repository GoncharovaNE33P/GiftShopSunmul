package com.example.giftshopsunmulapp.model

data class history(
    val id: String,
    val users_id: String,
    val products_id: String,
    val orders_id: String
)
