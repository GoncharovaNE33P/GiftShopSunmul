package com.example.giftshopsunmulapp.model

data class deliveryMethods(
    val id: String,
    val title: String
)
