package com.example.giftshopsunmulapp.model

import java.util.Date

data class user(
    val id: String,
    val name: String,
    val phone: String,
    val birthday: Date,
    val image: String
)
