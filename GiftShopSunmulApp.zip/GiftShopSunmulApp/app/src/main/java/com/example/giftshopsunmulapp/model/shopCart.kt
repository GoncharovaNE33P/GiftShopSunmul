package com.example.giftshopsunmulapp.model

data class shopCart(
    val id: String,
    val users_id: String,
    val products_id: String,
    val count: Int
)
