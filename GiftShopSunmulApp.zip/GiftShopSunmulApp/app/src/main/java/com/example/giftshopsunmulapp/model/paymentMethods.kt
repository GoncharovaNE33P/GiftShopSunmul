package com.example.giftshopsunmulapp.model

data class paymentMethods(
    val id: String,
    val title: String
)
