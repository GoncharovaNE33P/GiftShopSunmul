package com.example.giftshopsunmulapp.model

data class categories(
    val id: String,
    val title: String
)
