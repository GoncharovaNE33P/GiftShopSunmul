package com.example.giftshopsunmulapp.model

data class productsStatus(
    val id: String,
    val title: String
)
